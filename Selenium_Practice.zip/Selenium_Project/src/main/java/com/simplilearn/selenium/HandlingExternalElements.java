package com.simplilearn.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.Set;

public class HandlingExternalElements {
    public static void main(String[] args) {
    	
        // Set the path to the ChromeDriver executable
    	
        System.setProperty("webdriver.chrome.driver", "DRIVERS/WIN/chromedriver.exe");

        // Create a new instance of the ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to a webpage with a link that opens a new tab/window
        driver.get("https://www.google.com");

        // Handle external popups (if any)
        // Assume there is a button that triggers a popup
        WebElement popupButton = driver.findElement(By.id("popupButton"));
        popupButton.click();

        // Get the handle of the main window
        String mainWindowHandle = driver.getWindowHandle();

        // Get the handles of all open windows
        Set<String> allWindowHandles = driver.getWindowHandles();

        // Iterate through all handles
        for (String handle : allWindowHandles) {
            // Switch to the popup window
            if (!handle.equals(mainWindowHandle)) {
                driver.switchTo().window(handle);

                // Perform actions in the popup window
                // ...

                // Close the popup window
                driver.close();
            }
        }

        // Switch back to the main window
        driver.switchTo().window(mainWindowHandle);

        // Open a new tab
        WebElement newTabButton = driver.findElement(By.id("newTabButton"));
        newTabButton.click();

        // Get the handles of all open windows
        allWindowHandles = driver.getWindowHandles();

        // Iterate through all handles
        for (String handle : allWindowHandles) {
            // Switch to the new tab
            if (!handle.equals(mainWindowHandle)) {
                driver.switchTo().window(handle);

                // Perform actions in the new tab
                // ...

                // Close the new tab
                driver.close();
            }
        }

        // Close the main window
        driver.quit();
    }
}

