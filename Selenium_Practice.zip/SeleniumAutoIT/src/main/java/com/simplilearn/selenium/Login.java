package com.simplilearn.selenium;


	public class Login {

		public static final String username="priyajit2000";
		public static final String password="Priyajit@2000";
	}


