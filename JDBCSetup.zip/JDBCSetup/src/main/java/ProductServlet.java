
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));

        try (Connection connection = DBUtil.getConnection()) {
            String query = "SELECT * FROM products WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, productId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    PrintWriter out = response.getWriter();
                    if (resultSet.next()) {
                        String name = resultSet.getString("name");
                        double price = resultSet.getDouble("price");
                        String description = resultSet.getString("description");

                        out.println("<html><body>");
                        out.println("<h2>Product Details:</h2>");
                        out.println("<p>ID: " + productId + "</p>");
                        out.println("<p>Name: " + name + "</p>");
                        out.println("<p>Price: $" + price + "</p>");
                        out.println("<p>Description: " + description + "</p>");
                        out.println("</body></html>");
                    } else {
                        out.println("<html><body>");
                        out.println("<h2>Error:</h2>");
                        out.println("<p>Product not found for ID: " + productId + "</p>");
                        out.println("</body></html>");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException("Database error", e);
        }
    }
}
